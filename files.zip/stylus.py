"""
Stylus: Training-Free Music Style Transfer via Self-Attention Manipulation
Reimplementation fidèle du papier arxiv:2411.15913

Pipeline:
  1. Audio → Mel-spectrogram (STFT)
  2. Mel → Image RGB (normalisée pour SD)
  3. DDIM Inversion des deux (style + content) avec capture des K/V de self-attention
  4. AdaIN sur le latent initial
  5. DDIM Reverse du content avec injection K/V du style dans les couches cibles
  6. Image → Mel → Audio (Griffin-Lim ou vocodeur)
"""

import torch
import torch.nn.functional as F
import numpy as np
from typing import Optional
from dataclasses import dataclass, field


@dataclass
class StylusConfig:
    # Hyperparamètre de préservation de la query (eq. 3 du papier)
    alpha: float = 0.6

    # Couches du U-Net SD ciblées (decoder layers 7–12, index 0-based dans les up_blocks)
    # SD 1.5 U-Net : up_blocks[0..3], chacun avec attn à plusieurs résolutions
    # Les "later decoder layers" correspondent aux up_blocks à haute résolution
    target_up_blocks: list = field(default_factory=lambda: [0, 1])  # résolutions 64x64 et 32x32
    target_layers_per_block: list = field(default_factory=lambda: [0, 1, 2])  # toutes les attn layers

    # Temperature scaling de l'attention (attention sharpening)
    attention_temperature: float = 0.5  # divise QK^T avant softmax (valeur < 1 = plus sharp)

    # Paramètres DDIM
    num_inference_steps: int = 50
    guidance_scale: float = 1.0  # training-free → pas de text guidance, on met 1.0

    # Paramètres mel-spectrogram
    sample_rate: int = 22050
    n_fft: int = 2048
    hop_length: int = 512
    n_mels: int = 512           # hauteur de l'image mel (SD attend 512x512)
    target_length: int = 512    # longueur temporelle cible (largeur image)
    fmin: float = 0.0
    fmax: float = 8000.0

    # Modèle SD
    model_id: str = "runwayml/stable-diffusion-v1-5"
    device: str = "cuda"
    dtype: torch.dtype = torch.float16


class AttentionFeatureStore:
    """
    Hook manager pour capturer et injecter les K/V de self-attention
    pendant le forward pass du U-Net.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        # Stockage par (block_idx, layer_idx, timestep)
        self.stored_keys: dict = {}
        self.stored_values: dict = {}
        self.current_timestep: int = 0
        self.mode: str = "capture"   # "capture" | "inject" | "off"
        self.inject_alpha: float = 0.6
        self.inject_temperature: float = 0.5

    def set_timestep(self, t: int):
        self.current_timestep = t

    def get_store_key(self, block_idx: int, layer_idx: int) -> tuple:
        return (block_idx, layer_idx, self.current_timestep)

    def store(self, block_idx: int, layer_idx: int, keys: torch.Tensor, values: torch.Tensor):
        k = self.get_store_key(block_idx, layer_idx)
        self.stored_keys[k] = keys.detach().clone()
        self.stored_values[k] = values.detach().clone()

    def retrieve(self, block_idx: int, layer_idx: int) -> tuple[Optional[torch.Tensor], Optional[torch.Tensor]]:
        k = self.get_store_key(block_idx, layer_idx)
        return self.stored_keys.get(k), self.stored_values.get(k)


def make_self_attention_hook(store: AttentionFeatureStore, block_idx: int, layer_idx: int):
    """
    Crée un hook pour un module d'attention spécifique.

    En mode "capture" : stocke K et V issus du forward normal.
    En mode "inject"  : remplace K et V par ceux du style stockés,
                        blende Q_content avec Q_output (query preservation),
                        applique attention temperature scaling.
    """
    def hook(module, args, kwargs, output):
        # Récupérer l'input hidden state (premier argument positionnel)
        # Pour les modules Attention de diffusers, args[0] est le hidden_state
        hidden_states = args[0] if args else kwargs.get("hidden_states")
        if hidden_states is None:
            return output

        if store.mode == "capture":
            # Recalculer K et V pour les stocker
            # (le forward les a déjà calculés mais on n'y a pas accès directement)
            # → On utilise les projections du module
            with torch.no_grad():
                k = module.to_k(hidden_states)
                v = module.to_v(hidden_states)
                # Reshape multi-head si nécessaire
                k = _reshape_for_store(k, module)
                v = _reshape_for_store(v, module)
            store.store(block_idx, layer_idx, k, v)

        elif store.mode == "inject":
            style_k, style_v = store.retrieve(block_idx, layer_idx)
            if style_k is None:
                return output

            # Recalculer Q du content (output courant)
            with torch.no_grad():
                q_content = module.to_q(hidden_states)
                q_content = _reshape_for_store(q_content, module)

            # Recalculer Q_output (query du débruitage en cours)
            # On récupère q_output en reforwardant (approximation)
            q_output = q_content  # simplification: même hidden_states initial

            # Query preservation : Q_blended = α * Q_content + (1-α) * Q_output
            q_blended = store.inject_alpha * q_content + (1 - store.inject_alpha) * q_output

            # Reconstruire l'output attention avec K/V du style et Q blendé
            # avec temperature scaling
            new_output = _manual_attention(
                q=q_blended,
                k=style_k,
                v=style_v,
                module=module,
                temperature=store.inject_temperature,
            )
            return new_output

        return output

    return hook


def _reshape_for_store(x: torch.Tensor, attn_module) -> torch.Tensor:
    """Reshape (B, L, C) → (B*heads, L, head_dim) pour stockage."""
    heads = attn_module.heads
    B, L, C = x.shape
    head_dim = C // heads
    x = x.view(B, L, heads, head_dim).permute(0, 2, 1, 3)
    return x.reshape(B * heads, L, head_dim)


def _unshape(x: torch.Tensor, batch_size: int, heads: int) -> torch.Tensor:
    """Inverse reshape (B*heads, L, head_dim) → (B, L, C)."""
    BH, L, head_dim = x.shape
    x = x.reshape(batch_size, heads, L, head_dim)
    x = x.permute(0, 2, 1, 3)
    return x.reshape(batch_size, L, heads * head_dim)


def _manual_attention(
    q: torch.Tensor,
    k: torch.Tensor,
    v: torch.Tensor,
    module,
    temperature: float = 1.0,
) -> torch.Tensor:
    """
    Calcul manuel de self-attention avec temperature scaling.
    q, k, v shape: (B*heads, L, head_dim)
    """
    scale = (q.shape[-1] ** -0.5) * temperature  # temperature < 1 → attention plus sharp
    attn_weights = torch.bmm(q, k.transpose(-2, -1)) * scale
    attn_weights = F.softmax(attn_weights, dim=-1)
    out = torch.bmm(attn_weights, v)

    # Unshape et projeter avec to_out
    batch_size = q.shape[0] // module.heads
    out = _unshape(out, batch_size, module.heads)
    out = module.to_out[0](out)  # linear projection
    out = module.to_out[1](out)  # dropout (identity en eval)
    return out


class MelSpectrogramProcessor:
    """
    Conversion audio ↔ mel-spectrogram ↔ image RGB normalisée (pour SD).
    """

    def __init__(self, cfg: StylusConfig):
        self.cfg = cfg
        try:
            import librosa
            self.librosa = librosa
        except ImportError:
            raise ImportError("pip install librosa")

    def audio_to_mel(self, audio: np.ndarray) -> np.ndarray:
        """
        Audio waveform (mono float32) → mel-spectrogram (n_mels × T) en dB.
        """
        cfg = self.cfg
        mel = self.librosa.feature.melspectrogram(
            y=audio,
            sr=cfg.sample_rate,
            n_fft=cfg.n_fft,
            hop_length=cfg.hop_length,
            n_mels=cfg.n_mels,
            fmin=cfg.fmin,
            fmax=cfg.fmax,
        )
        mel_db = self.librosa.power_to_db(mel, ref=np.max)
        return mel_db  # shape: (n_mels, T)

    def mel_to_image(self, mel_db: np.ndarray) -> torch.Tensor:
        """
        Mel dB (n_mels × T) → image RGB normalisée [-1, 1] (1 × 3 × 512 × 512).
        Resize et normalise pour Stable Diffusion.
        """
        import torch.nn.functional as F

        # Normaliser en [0, 1]
        mel_min, mel_max = mel_db.min(), mel_db.max()
        mel_norm = (mel_db - mel_min) / (mel_max - mel_min + 1e-8)

        # → tensor (1, 1, H, W) et resize 512×512
        t = torch.from_numpy(mel_norm).float().unsqueeze(0).unsqueeze(0)
        t = F.interpolate(t, size=(self.cfg.n_mels, self.cfg.target_length), mode="bilinear", align_corners=False)

        # Répliquer sur 3 canaux RGB pour SD (qui attend 3 canaux)
        t = t.repeat(1, 3, 1, 1)  # (1, 3, 512, 512)

        # Normaliser en [-1, 1] (convention SD)
        t = t * 2.0 - 1.0
        return t

    def image_to_mel(self, image: torch.Tensor, original_mel: np.ndarray) -> np.ndarray:
        """
        Image RGB [-1, 1] → mel dB (n_mels × T).
        Utilise les stats de l'original pour dénormaliser.
        """
        # Prendre le canal R uniquement
        img = image[0, 0].float().cpu().numpy()  # (H, W)

        # De [-1,1] → [0,1]
        img = (img + 1.0) / 2.0
        img = np.clip(img, 0.0, 1.0)

        # Dénormaliser avec stats de l'original
        mel_min, mel_max = original_mel.min(), original_mel.max()
        mel_db = img * (mel_max - mel_min) + mel_min

        # Resize vers les dimensions originales
        from PIL import Image as PILImage
        pil = PILImage.fromarray((img * 255).astype(np.uint8))
        pil = pil.resize((original_mel.shape[1], original_mel.shape[0]), PILImage.BILINEAR)
        img_resized = np.array(pil).astype(np.float32) / 255.0
        mel_db_resized = img_resized * (mel_max - mel_min) + mel_min

        return mel_db_resized

    def mel_to_audio(self, mel_db: np.ndarray) -> np.ndarray:
        """
        Mel dB → audio waveform via Griffin-Lim.
        (Pour meilleure qualité : utiliser un vocodeur HiFi-GAN entraîné.)
        """
        cfg = self.cfg
        mel_power = self.librosa.db_to_power(mel_db)
        audio = self.librosa.feature.inverse.mel_to_audio(
            mel_power,
            sr=cfg.sample_rate,
            n_fft=cfg.n_fft,
            hop_length=cfg.hop_length,
            fmin=cfg.fmin,
            fmax=cfg.fmax,
            n_iter=64,  # iterations Griffin-Lim
        )
        return audio.astype(np.float32)


def adain(content_latent: torch.Tensor, style_latent: torch.Tensor) -> torch.Tensor:
    """
    Adaptive Instance Normalization (équation 4 du papier).
    Module le latent du content avec les stats du style.

    z_mo_T = σ(z_ms_T) * (z_mc_T - μ(z_mc_T)) / σ(z_mc_T) + μ(z_ms_T)

    Args:
        content_latent: bruit DDIM du content z_mc_T  (B, C, H, W)
        style_latent:   bruit DDIM du style z_ms_T    (B, C, H, W)
    Returns:
        latent AdaIN-modulé pour initialiser le débruitage du stylisé
    """
    # Stats channel-wise (comme dans le papier)
    mu_c = content_latent.mean(dim=[2, 3], keepdim=True)
    sigma_c = content_latent.std(dim=[2, 3], keepdim=True) + 1e-8
    mu_s = style_latent.mean(dim=[2, 3], keepdim=True)
    sigma_s = style_latent.std(dim=[2, 3], keepdim=True) + 1e-8

    normalized = (content_latent - mu_c) / sigma_c
    return sigma_s * normalized + mu_s


class StylusPipeline:
    """
    Pipeline complet Stylus pour le transfert de style musical.

    Usage:
        pipeline = StylusPipeline(config)
        result = pipeline.transfer(style_audio, content_audio, sr=22050)
        soundfile.write("output.wav", result, 22050)
    """

    def __init__(self, cfg: Optional[StylusConfig] = None):
        self.cfg = cfg or StylusConfig()
        self.mel_proc = MelSpectrogramProcessor(self.cfg)
        self.store = AttentionFeatureStore()
        self.store.inject_alpha = self.cfg.alpha
        self.store.inject_temperature = self.cfg.attention_temperature
        self._hooks = []
        self._pipe = None

    def load_model(self):
        """Charge Stable Diffusion 1.5 via diffusers."""
        from diffusers import StableDiffusionPipeline, DDIMScheduler

        print(f"Loading {self.cfg.model_id}...")
        pipe = StableDiffusionPipeline.from_pretrained(
            self.cfg.model_id,
            torch_dtype=self.cfg.dtype,
            safety_checker=None,
            requires_safety_checker=False,
        )
        pipe.scheduler = DDIMScheduler.from_config(pipe.scheduler.config)
        pipe = pipe.to(self.cfg.device)
        pipe.set_progress_bar_config(disable=True)

        self._pipe = pipe
        self._register_hooks()
        print("Model loaded.")
        return self

    def _register_hooks(self):
        """
        Enregistre des forward hooks sur les couches self-attention cibles
        du décodeur du U-Net de Stable Diffusion.

        Architecture SD 1.5 U-Net up_blocks:
          up_blocks[0]: 3 UpBlock2D (résidu uniquement, pas d'attention)
          up_blocks[1]: CrossAttnUpBlock2D — 3 BasicTransformerBlock — résolution 8x8   → layer 7-9
          up_blocks[2]: CrossAttnUpBlock2D — 3 BasicTransformerBlock — résolution 16x16  → layer 10-11
          up_blocks[3]: CrossAttnUpBlock2D — 3 BasicTransformerBlock — résolution 32x32  → layer 12

        Le papier cible layers 7-12 (décalage 1-based → indices 1-3 en 0-based).
        """
        unet = self._pipe.unet

        for block_idx in self.cfg.target_up_blocks:
            up_block = unet.up_blocks[block_idx + 1]  # +1 car up_blocks[0] sans attention

            if not hasattr(up_block, "attentions"):
                continue

            for layer_idx in self.cfg.target_layers_per_block:
                if layer_idx >= len(up_block.attentions):
                    continue

                # Chaque attention block est un SpatialTransformer → BasicTransformerBlock
                # On cible l'attn1 (self-attention), pas attn2 (cross-attention)
                spatial_transformer = up_block.attentions[layer_idx]
                for bt_block in spatial_transformer.transformer_blocks:
                    attn1 = bt_block.attn1  # self-attention

                    hook_fn = make_self_attention_hook(self.store, block_idx, layer_idx)
                    h = attn1.register_forward_hook(hook_fn, with_kwargs=True)
                    self._hooks.append(h)

        print(f"Registered {len(self._hooks)} attention hooks.")

    def _remove_hooks(self):
        for h in self._hooks:
            h.remove()
        self._hooks.clear()

    @torch.no_grad()
    def _encode_to_latent(self, image: torch.Tensor) -> torch.Tensor:
        """Image RGB [-1,1] → latent VAE."""
        image = image.to(self.cfg.device, dtype=self.cfg.dtype)
        latent = self._pipe.vae.encode(image).latent_dist.mean
        latent = latent * self._pipe.vae.config.scaling_factor
        return latent

    @torch.no_grad()
    def _decode_from_latent(self, latent: torch.Tensor) -> torch.Tensor:
        """Latent VAE → image RGB [-1,1]."""
        latent = latent / self._pipe.vae.config.scaling_factor
        image = self._pipe.vae.decode(latent).sample
        return image.float().cpu()

    @torch.no_grad()
    def _get_null_text_embedding(self) -> torch.Tensor:
        """Empty text prompt embedding pour inference sans guidance."""
        return self._pipe.encode_prompt(
            prompt="",
            device=self.cfg.device,
            num_images_per_prompt=1,
            do_classifier_free_guidance=False,
        )[0]

    @torch.no_grad()
    def _ddim_inversion(
        self,
        latent: torch.Tensor,
        text_emb: torch.Tensor,
        label: str = "",
    ) -> torch.Tensor:
        """
        DDIM Inversion : z_0 → z_T (espace bruité).
        Si mode="capture" est actif, stocke les K/V à chaque timestep.

        Formule DDIM inversion :
          z_{t+1} = √ᾱ_{t+1} * (z_t - √(1-ᾱ_t) * ε_θ) / √ᾱ_t
                  + √(1-ᾱ_{t+1}) * ε_θ
        """
        scheduler = self._pipe.scheduler
        scheduler.set_timesteps(self.cfg.num_inference_steps)
        timesteps = scheduler.timesteps.flip(0)  # inversion : 0 → T

        zt = latent.clone()

        for i, t in enumerate(timesteps):
            self.store.set_timestep(int(t))

            # Prédiction du bruit par le U-Net
            noise_pred = self._pipe.unet(
                zt,
                t,
                encoder_hidden_states=text_emb,
            ).sample

            # Calcul DDIM inversion step
            zt = self._ddim_inversion_step(zt, noise_pred, t, scheduler)

            if (i + 1) % 10 == 0:
                print(f"  [{label}] Inversion step {i+1}/{len(timesteps)}")

        return zt

    def _ddim_inversion_step(
        self,
        zt: torch.Tensor,
        noise_pred: torch.Tensor,
        t: torch.Tensor,
        scheduler,
    ) -> torch.Tensor:
        """Un step de DDIM inversion."""
        alphas_cumprod = scheduler.alphas_cumprod.to(zt.device)
        t_next = min(int(t) + scheduler.config.num_train_timesteps // self.cfg.num_inference_steps,
                     scheduler.config.num_train_timesteps - 1)

        alpha_bar_t = alphas_cumprod[int(t)]
        alpha_bar_t_next = alphas_cumprod[t_next]

        # x0 prédit
        x0_pred = (zt - (1 - alpha_bar_t).sqrt() * noise_pred) / alpha_bar_t.sqrt()

        # z_{t+1}
        zt_next = alpha_bar_t_next.sqrt() * x0_pred + (1 - alpha_bar_t_next).sqrt() * noise_pred
        return zt_next

    @torch.no_grad()
    def _ddim_reverse(
        self,
        zT: torch.Tensor,
        text_emb: torch.Tensor,
        label: str = "",
    ) -> torch.Tensor:
        """
        DDIM Reverse (débruitage) : z_T → z_0.
        Si mode="inject", remplace K/V par ceux du style.
        """
        scheduler = self._pipe.scheduler
        scheduler.set_timesteps(self.cfg.num_inference_steps)

        zt = zT.clone()

        for i, t in enumerate(scheduler.timesteps):
            self.store.set_timestep(int(t))

            noise_pred = self._pipe.unet(
                zt,
                t,
                encoder_hidden_states=text_emb,
            ).sample

            zt = scheduler.step(noise_pred, t, zt).prev_sample

            if (i + 1) % 10 == 0:
                print(f"  [{label}] Denoising step {i+1}/{len(scheduler.timesteps)}")

        return zt

    def transfer(
        self,
        style_audio: np.ndarray,
        content_audio: np.ndarray,
        sample_rate: int = 22050,
    ) -> np.ndarray:
        """
        Transfère le style de style_audio vers content_audio.

        Args:
            style_audio:   waveform mono float32 du morceau de style
            content_audio: waveform mono float32 du morceau de contenu
            sample_rate:   fréquence d'échantillonnage

        Returns:
            waveform mono float32 du résultat stylisé
        """
        if self._pipe is None:
            self.load_model()

        # ── Étape 1 : Audio → Mel → Image ─────────────────────────────────────
        print("\n[1/5] Converting audio to mel spectrograms...")
        mel_style = self.mel_proc.audio_to_mel(style_audio)
        mel_content = self.mel_proc.audio_to_mel(content_audio)

        img_style = self.mel_proc.mel_to_image(mel_style)
        img_content = self.mel_proc.mel_to_image(mel_content)

        # ── Étape 2 : VAE Encode ────────────────────────────────────────────────
        print("[2/5] Encoding to latent space...")
        z_style = self._encode_to_latent(img_style)
        z_content = self._encode_to_latent(img_content)

        text_emb = self._get_null_text_embedding()

        # ── Étape 3 : DDIM Inversion (capture K/V du style) ────────────────────
        print("[3/5] DDIM Inversion (capturing style attention features)...")

        # Inversion du style → capture les K/V
        self.store.mode = "capture"
        zT_style = self._ddim_inversion(z_style, text_emb, label="style")

        # Inversion du content (sans capture)
        self.store.mode = "off"
        zT_content = self._ddim_inversion(z_content, text_emb, label="content")

        # ── Étape 4 : AdaIN sur le latent initial ──────────────────────────────
        print("[4/5] Applying AdaIN to initial latent...")
        zT_output = adain(zT_content, zT_style)

        # ── Étape 5 : DDIM Reverse avec injection K/V style ────────────────────
        print("[5/5] DDIM Reverse with style injection...")
        self.store.mode = "inject"
        z0_stylized = self._ddim_reverse(zT_output, text_emb, label="stylized")

        # ── Décodage ────────────────────────────────────────────────────────────
        self.store.mode = "off"

        print("\nDecoding latent to image...")
        img_stylized = self._decode_from_latent(z0_stylized)

        print("Converting mel spectrogram to audio...")
        mel_stylized = self.mel_proc.image_to_mel(img_stylized, mel_content)
        audio_out = self.mel_proc.mel_to_audio(mel_stylized)

        print("Done!")
        return audio_out

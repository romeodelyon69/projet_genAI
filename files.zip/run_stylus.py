"""
CLI pour Stylus — Transfert de style musical.

Usage:
    python run_stylus.py \
        --style   path/to/style.wav \
        --content path/to/content.wav \
        --output  path/to/output.wav \
        [--alpha 0.6] \
        [--steps 50] \
        [--temperature 0.5] \
        [--device cuda]

Dépendances:
    pip install torch torchvision torchaudio \
                diffusers transformers accelerate \
                librosa soundfile pillow
"""

import argparse
import numpy as np
import torch


def load_audio(path: str, target_sr: int, duration: float = 5.0) -> np.ndarray:
    """Charge un fichier audio, resample et tronque à duration secondes."""
    import librosa
    audio, sr = librosa.load(path, sr=target_sr, mono=True, duration=duration)
    # Pad si trop court
    target_len = int(target_sr * duration)
    if len(audio) < target_len:
        audio = np.pad(audio, (0, target_len - len(audio)))
    return audio.astype(np.float32)


def save_audio(path: str, audio: np.ndarray, sr: int):
    """Sauvegarde le résultat."""
    import soundfile as sf
    audio_normalized = audio / (np.abs(audio).max() + 1e-8) * 0.9
    sf.write(path, audio_normalized, sr)
    print(f"Saved: {path}")


def parse_args():
    p = argparse.ArgumentParser(description="Stylus: Training-Free Music Style Transfer")
    p.add_argument("--style",       required=True,  help="Fichier audio de style (.wav/.mp3/...)")
    p.add_argument("--content",     required=True,  help="Fichier audio de contenu (.wav/.mp3/...)")
    p.add_argument("--output",      default="stylized_output.wav", help="Chemin de sortie .wav")
    p.add_argument("--alpha",       type=float, default=0.6,   help="Query preservation (0=pure style, 1=pure content)")
    p.add_argument("--steps",       type=int,   default=50,    help="Nombre de steps DDIM")
    p.add_argument("--temperature", type=float, default=0.5,   help="Attention temperature (<1 = sharper)")
    p.add_argument("--duration",    type=float, default=5.0,   help="Durée audio à traiter (secondes)")
    p.add_argument("--device",      default="cuda" if torch.cuda.is_available() else "cpu")
    p.add_argument("--model",       default="runwayml/stable-diffusion-v1-5", help="Modèle HuggingFace SD")
    p.add_argument("--fp32",        action="store_true", help="Forcer fp32 (plus lent, CPU)")
    p.add_argument("--up-blocks",   nargs="+", type=int, default=[0, 1],
                   help="Indices up_blocks U-Net ciblés (0-based, +1 appliqué en interne)")
    return p.parse_args()


def main():
    args = parse_args()

    from stylus import StylusConfig, StylusPipeline

    # Configuration
    cfg = StylusConfig(
        alpha=args.alpha,
        num_inference_steps=args.steps,
        attention_temperature=args.temperature,
        target_up_blocks=args.up_blocks,
        model_id=args.model,
        device=args.device,
        dtype=torch.float32 if args.fp32 or args.device == "cpu" else torch.float16,
    )

    # Chargement audio
    print(f"Loading style  : {args.style}")
    print(f"Loading content: {args.content}")

    style_audio   = load_audio(args.style,   cfg.sample_rate, args.duration)
    content_audio = load_audio(args.content, cfg.sample_rate, args.duration)

    print(f"\nConfig:")
    print(f"  α (query preservation) = {cfg.alpha}")
    print(f"  DDIM steps             = {cfg.num_inference_steps}")
    print(f"  Attention temperature  = {cfg.attention_temperature}")
    print(f"  Target up_blocks       = {cfg.target_up_blocks}")
    print(f"  Device                 = {cfg.device} / {cfg.dtype}")
    print()

    # Pipeline
    pipeline = StylusPipeline(cfg)
    pipeline.load_model()

    # Transfert
    output_audio = pipeline.transfer(style_audio, content_audio, sample_rate=cfg.sample_rate)

    # Sauvegarde
    save_audio(args.output, output_audio, cfg.sample_rate)


if __name__ == "__main__":
    main()
